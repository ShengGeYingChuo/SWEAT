<?php
$conn = new mysqli("localhost","root","","SWEAT");

$sql=$_GET["code"];
$prof=$_GET["prof"];
$type=$_GET["type"];

$start_date = new DateTime('2023-09-27');


$result=mysqli_query($conn,$sql);
$table="";

if($type==0){
	$table.="<section id='".$prof."' style=''>
	<h2 style='border-bottom:1px solid #1E1E1E;' ><strong>".$prof."</strong></h2><div style='display:flex;justify-content:right;' ><button type='button' onclick='del_prof(".'"'.$prof.'"'.")'>delete this program</button>"."<button type='button' onclick='prof_remove(".'"'.$prof.'"'.")'>hide</button></div></br>";
}else if($type==1){
	$table.="<section id='".$prof."' style=''>
	<h2 style='border-bottom:1px solid #1E1E1E;' ><strong>".$prof."</strong></h2><div style='display:flex;justify-content:right;' ><a href='#feedback' ><button onclick='s_h_feedback()' >Feedback</button></a><button type='button' onclick='del_mod(".'"'.$prof.'"'.")'>delete this module</button>"."<button type='button' onclick='prof_remove(".'"'.$prof.'"'.")'>hide</button>"."<button type='button' onclick='log(".'"'.$prof.'"'.")'>log</button></div><div id='log'></div></br>";
}

while($row=mysqli_fetch_assoc($result)){
	$table.="<table id='".$row['code']."' style='margin-left:20px;margin-bottom:50px;margin-right:10px;width:90%;';>
				<tr>
					<th rowspan='3'>".$row['code']."</th>
					<th colspan='6'>name</th>
					<th colspan='4'>co_odinator</th>
					<th colspan='2'>semester </th>
					<th>credits</th>
					<th>CA"."(%)"."</th>
					<th rowspan='4'>
						<button type='button' onclick='obj_unshow(".'"'.$row['code'].'"'.',"'.$prof.'"'.")'>hide</button><br />
						<button id='s_h_detail' type='button' onclick='s_h_detail(".'"'.$row['code'].'"'.',"'.$prof.'"'.")'>hrs detail</button><br />
						<button type='button' onclick='modify(".'"'.$row['code'].'"'.',"'.$prof.'"'.")'>modify</button>
						
					</th>
				</tr>
				<tr>";
	if($row['name']!==null){
		$table.="<td colspan='6'>".$row['name']."</td>";
	}else{
		$table.="<td colspan='6'></td>";
	}
	
	if($row['co_odinator']!==null){
		$table.="<td colspan='4'>".$row['co_odinator']."</td>";
	}else{
		$table.="<td colspan='4'></td>";
	}
		
	if($row['semester']!==null){
		$table.="<td colspan='2'>".$row['semester']."</td>";
	}else{
		$table.="<td colspan='2'></td>";
	}
		
	if($row['Credits']!==null){
		$table.="<td>".$row['Credits']."</td>";
	}else{
		$table.="<td></td>";
	}
	
	if($row['CA']!==null){
		$table.="<td>".$row['CA']."</td>";
	}else{
		$table.="<td></td>";
	}

	$table.="</tr>";
						
	if($row['Nb_of_Coursework']==0){
		$table.="<tr>
					<th colspan='14'>0 coursework founded</th>
				</tr>";
	}else{
		$cs=json_decode($row['Course_work']);


		#检测是否有无效数据，并修复
		for($i=0;$i<sizeof($cs);$i++){ 
			if(empty($cs[$i]->name) && empty($cs[$i]->weitghing) && empty($cs[$i]->expct_hrs) && empty($cs[$i]->DL_A) && empty($cs[$i]->DL_B)){
				unset($cs[$i]);
				$i--;
			}
		}
		$row['Nb_of_Coursework']=sizeof($cs);
		if(json_encode($cs)!=$row['Course_work']){#移除无效数据
			$sql="UPDATE module SET Nb_of_Coursework='".$row['Nb_of_Coursework']."', Course_work='".json_encode($cs)."' WHERE code='".$row['code']."';";
			mysqli_query($conn,$sql);
		}
		
		$table.="<tr>
					<th colspan='13'>total coursework:</th>
					<th id='nb_coursework'>".$row['Nb_of_Coursework']."</th>
				</tr>
					<th colspan='2'>Type</th>
					<th colspan='5'>Name</th>
					<th colspan='1'>Weitghing</th>
					<th colspan='1'>Expect_hrs</th>
					<th colspan='1'>Predict_hrs</th>
					<th colspan='1'>Extra_hrs</th>
					<th colspan='2'>DL_Week for A</th>
					<th colspan='2'>DL_Week for B</th>
				</tr>";
				
		
		for($i=0;$i<$row['Nb_of_Coursework'];$i++){
			$table.="<tr>";
			
			if(isset($cs[$i]->type) && !empty($cs[$i]->type)){
				$table.="<td colspan='2'>".$cs[$i]->type."</td>";
			}else{
				$table.="<td colspan='2'> </td>";
			}
			
			if(isset($cs[$i]->name) && !empty($cs[$i]->name)){
				$table.="<td colspan='5'>".$cs[$i]->name."</td>";
			}else{
				$table.="<td colspan='5'> </td>";
			}
				
			if(isset($cs[$i]->weitghing) && !empty($cs[$i]->weitghing)){
				$table.="<td colspan='1'>".$cs[$i]->weitghing."</td>";
			}else{
				$table.="<td colspan='1' </td>";
			}
				
			if(isset($cs[$i]->expct_hrs) && !empty($cs[$i]->expct_hrs)){
				$table.="<td colspan='1'>".$cs[$i]->expct_hrs."</td>";
			}else{
				$table.="<td colspan='1'> </td>";
			}
			
			if(isset($cs[$i]->predict_hrs) && !empty($cs[$i]->predict_hrs)){
				$table.="<td colspan='1'>".$cs[$i]->predict_hrs."</td>";
			}else{
				$table.="<td colspan='1'> </td>";
			}
			
			if(isset($cs[$i]->extra_hrs) && !empty($cs[$i]->extra_hrs)){
				$table.="<td colspan='1'>".$cs[$i]->extra_hrs."</td>";
			}else{
				$table.="<td colspan='1'> </td>";
			}
			
				
			if(isset($cs[$i]->DL_A) && !empty($cs[$i]->DL_A)){
				if(gettype($cs[$i]->DL_A)=="string"){
					$diff = $start_date->diff(new DateTime($cs[$i]->DL_A));
					$weeks = floor($diff->days / 7);
					$table.="<td>".$cs[$i]->DL_A."</td><td>(week ".$weeks.")</td>";
				}else{
					$table.="<td> </td><td>(week ".$cs[$i]->DL_A.")</td>";
				}
			}else{
				$table.="<td colspan='2'> </td>";
			}
				
			if(isset($cs[$i]->DL_B) && !empty($cs[$i]->DL_B)){
				if(gettype($cs[$i]->DL_B)=="string"){
					$diff = $start_date->diff(new DateTime($cs[$i]->DL_B));
					$weeks = floor($diff->days / 7);
					$table.="<td >".$cs[$i]->DL_B."</td><td>(week ".$weeks.")</td>";
				}else{
					$table.="<td> </td><td>(week ".$cs[$i]->DL_B.")</td>";
				}
			}else{
				$table.="<td colspan='2'> </td>";
			}
			
			$table.="<td></td>";
			$table.="</tr>";
		}
	}

	
	
	//===============================
	
	$table.="<tr class='detail' style='display:none'><th colspan='16' style='height:15px;'>  </th></tr><tr class='detail' style='display:none'><th></th>";
	for($i=1;$i<16;$i++){
		$table.="<th>week ".$i."</th>";
	}
	$table.="</tr><tr class='detail' style='display:none'><th>Contact hrs</th>";
	$tmp=json_decode($row["contact_hrs"]);
	for($i=0;$i<15;$i++){
		if(isset($tmp[$i]) && !empty($tmp[$i])){
			$table.="<td>".$tmp[$i]."</th>";
		}else{
			$table.="<td>0</td>";
		}
	}
	
	$table.="</tr><tr class='detail' style='display:none'><th>predict_hrs</th>";
	$tmp=json_decode($row["predict_hrs"]);
	for($i=0;$i<15;$i++){
		if(isset($tmp[$i]) && !empty($tmp[$i])){
			$table.="<td>".$tmp[$i]."</th>";
		}else{
			$table.="<td>0</td>";
		}
	}
	
	$table.="</tr><tr class='detail' style='display:none'><th>extra_hrs</th>";
	$tmp=json_decode($row["extra_hrs"]);
	for($i=0;$i<15;$i++){
		if(isset($tmp[$i]) && !empty($tmp[$i])){
			$table.="<td>".$tmp[$i]."</th>";
		}else{
			$table.="<td>0</td>";
		}
	}
	$table.="</tr><tr class='detail' style='display:none'><th>CA_predict_time</th>";
	$tmp=json_decode($row["CA_predict_time"]);
	for($i=0;$i<15;$i++){
		if(isset($tmp[$i]) && !empty($tmp[$i])){
			$table.="<td>".$tmp[$i]."</th>";
		}else{
			$table.="<td>0</td>";
		}
	}
	
	$table.="</tr><tr class='detail' style='display:none'><th>CA_extra_time</th>";
	$tmp=json_decode($row["CA_extra_time"]);
	for($i=0;$i<15;$i++){
		if(isset($tmp[$i]) && !empty($tmp[$i])){
			$table.="<td>".$tmp[$i]."</th>";
		}else{
			$table.="<td>0</td>";
		}
	}
	
	
	
	
	$table.="</tr><tr class='detail' style='display:none'><td colspan='16'> <button type='button' onclick='modify_t(".'"'.$row['code'].'"'.',"'.$prof.'"'.")'>modify</button><button type='button' onclick='data_t(".'"'.$row['code'].'"'.',"'.$prof.'"'.")'>show graph</button> <button type='button' style='display:none;' onclick='hide_t( ".'"'.$row['code'].'"'.',"'.$prof.'"'.")'>hide graph</button></td></tr></tr>";
	
	//Final exam week
	
	$table.="<tr><th colspan='13'>Final Exam Week:</th><th colspan='3'>".$row['Final_Exam_Week']."</th></tr>";
	$table.="</table>";
	
	
}


if($type==0 || $type==1){
	$table.="</section>";
}


echo $table;	

$conn->close();
?>